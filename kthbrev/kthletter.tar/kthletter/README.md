# kthletter
Class for letters at KTH.

Check `exampleletter.tex` for an example on how to create letters.
